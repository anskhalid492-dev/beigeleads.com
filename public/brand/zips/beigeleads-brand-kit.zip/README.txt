BeigeLeads brand assets (v1.0, November 2026)
Use the logo as supplied: do not recolour, stretch, rotate or add effects. See guidelines/beigeleads-brand-guidelines.pdf.
Colours: Forest 900 #0f2a1d, Forest 700 #1b4332, Forest 500 #2d6a4f, Forest 300 #8fd0a9, Sand 50 #fbf8f1, Sand 200 #e8dec6, Purple 600 #7c3aed (buttons only).
Font: Bricolage Grotesque (SIL Open Font License). Questions: https://beigeleads.com/contact
